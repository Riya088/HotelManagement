package com.hotelmanagement.dto;

import lombok.Data;

@Data
public class CommanApiResponse {
	
	private int responseCode;
	
	private String responseMessage;
	
}
