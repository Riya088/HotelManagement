package com.hotelmanagement.dto;

import lombok.Data;

@Data
public class HotelFacilityAddRequest {
	
	private int hotelId;
	
	private int facilityId; 
	
}
