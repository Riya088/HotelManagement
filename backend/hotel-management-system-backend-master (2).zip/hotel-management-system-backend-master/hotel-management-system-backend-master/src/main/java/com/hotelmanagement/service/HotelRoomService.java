package com.hotelmanagement.service;

import org.springframework.stereotype.Service;

@Service
public class HotelRoomService {

}
